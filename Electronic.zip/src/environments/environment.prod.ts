export const environment = {
  production: true,
  serviceApiUrl: 'https://oxalisservice-dev.azurewebsites.net'
};