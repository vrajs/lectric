import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Utils } from '../common/app-functions';
import { MatDialog } from '@angular/material/dialog';
import { AppConstant } from '../common/app-constants';
import { CustomConfirmDialogComponent } from '../Shared/custom-confirm-dialog/custom-confirm-dialog.component';
import { CustomConfimDialogModel } from '../../app/common/custome-confirm-dialog.model';
import { CommonCodeConfigurationModel } from '../../app/core/models/common/common-code-configuration.model';
import { StandAloneService } from '../core/services/stand-alone.service';
import { accessibilityFormatFontSize, accessibilityFormatLanguage, CodeType, Page, HealthPlan, RecordStatus } from '../common/app-enum';
import { CommonCodeModel } from '../core/models/common/common-code.model';
import { debounceTime, distinctUntilChanged, filter, forkJoin } from 'rxjs';
import { SEPReasonCodeTypeModel } from '../core/models/common/sepReasonCodeType.model';
import { PreEnrollmentModel } from '../core/models/common/PreEnrollment.model';
import { AuthService } from '../core/services/auth.service';
import { formatDate } from '@angular/common';
import { MatCheckboxChange } from '@angular/material/checkbox';

@Component({
  selector: 'app-PreEnrollmentForm',
  templateUrl: './PreEnrollmentForm.component.html',
  styleUrls: ['./PreEnrollmentForm.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PreEnrollmentFormComponent implements OnInit {
  // Section Active Variables Declaration starts
  activeSection: number = 1;
  isFirstCalling: boolean = true;
  public PreEnrollmentObj: PreEnrollmentModel = new PreEnrollmentModel();
  // Section Active Variables Declaration end

  //HealthPlan, Gender, Salutation, RelationShip, Lists variables Declaration starts
  contractList: CommonCodeModel[] = [];
  PBPList: CommonCodeModel[] = [];
  raceList: CommonCodeModel[] = [];
  ethnicityList: CommonCodeModel[] = [];
  emergencyContactRelationshipList: CommonCodeModel[] = [];
  contactTypeList: CommonCodeModel[] = [];
  genderList: CommonCodeConfigurationModel[] = [];
  initialsList: CommonCodeModel[] = [];
  finalQuestionnaire: SEPReasonCodeTypeModel[] = [];

  //HealthPlan, Gender, Salutation, RelationShip, Lists variables Declaration ends  

  //HealthPlan variables Declaration starts

  defaultHealthPlan: any = HealthPlan.HPS;
  selectedValues: string[] = []; // Array to hold selected values
  selectedPrintValues: string[] = []; // Array to hold selected values

  //HealthPlan variables Declaration ends

  // Date variables Declaration start

  myFilter = (d: Date | null): boolean => {
    const date = (d || new Date()).getDate();
    return date == 1;
  };

  todayDate: Date = new Date();
  YesterdayDate: Date = new Date();

  dateEnable: boolean = true;

  partADateValid: boolean = true;
  partBDateValid: boolean = true;

  // Date variables Declaration ends

  // BenefitedBy variables Declaration starts

  checkedBenefitedBy: string = "";
  checkedfoundGoldKidney: string = "";

  // BenefitedBy variables Declaration ends

  // Address variables Declaration starts

  mailingAddressReadonly: boolean = false;
  isPA1Valid: boolean = true;
  mailZipCodeValid: boolean = true;

  // Address variables Declaration ends

  // Medicade, Drug and Other Coverage variables Declaration starts

  drugCoverageEnableDisable: boolean = false;
  mediEnableDisable: boolean = false;
  //MemberEnrollmentHeader values 
  lobid: number = 0;
  planTypeVal = "";
  tPbpIDs: Array<string> = [];
  finalFound: any = '';
  finalPrintFound: any = '';
  // Medicade, Drug and Other Coverage  variables Declaration ends

  @ViewChild('mbiInput') mbiInput!: ElementRef;
  @ViewChild('medicaidInput') medicaidInput!: ElementRef;
  @ViewChild('salesAgentId') salesAgentIdInput!: ElementRef;
  @ViewChild('emailAddress') emailAddress!: ElementRef;

  standAloneForm1 = new FormGroup({
    contractType: new FormControl(null),
    PCPName: new FormControl(null, [Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]),
    NepName: new FormControl(null, [Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]),
    NepPhoneNumber: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    NepCity: new FormControl(null),
    speciality: new FormControl(null),
    city: new FormControl(null),
    phoneNumber: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    PCPName2: new FormControl(null, [Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]),
    speciality2: new FormControl(null),
    city2: new FormControl(null),
    phoneNumber2: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    faxNumber2: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    PCPName3: new FormControl(null, [Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]),
    speciality3: new FormControl(null),
    city3: new FormControl(null),
    phoneNumber3: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    faxNumber3: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    medicalGroup: new FormControl(null),
    planType: new FormControl(null, Validators.required),
    initials: new FormControl(null, Validators.required),
    firstName: new FormControl(null, [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z]*$')]),
    lastName: new FormControl(null, [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z]*$')]),
    middleName: new FormControl(null, [Validators.maxLength(1), Validators.pattern('^[a-zA-Z]*$')]),
    dob: new FormControl(null, Validators.required),
    gender: new FormControl(null, Validators.required),
    homePhoneNo: new FormControl(null, [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    cellPhoneNo: new FormControl(null, [Validators.minLength(10), Validators.maxLength(10)]),
    emailAddress: new FormControl(null, [Validators.email]),
    contactPrefrence: new FormControl('5902', [Validators.required]),
    permanentAddress: new FormControl(null, [Validators.required]),
    permanentAddressCity: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z. ]*$')]),
    permanentAddressState: new FormControl('', [Validators.required, Validators.maxLength(2), Validators.pattern('^[a-zA-Z. ]*$')]),
    permanentAddressZipCode: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(9), Validators.pattern('^[0-9]*$')]),
    mailingAddress: new FormControl(null),
    mailingAddressCity: new FormControl('', [Validators.pattern('^[a-zA-Z. ]*$')]),
    mailingAddressState: new FormControl('', [Validators.maxLength(2), Validators.pattern('^[a-zA-Z. ]*$')]),
    mailingAddressZipCode: new FormControl('', [Validators.minLength(5), Validators.maxLength(9), Validators.pattern('^[0-9]*$')]),
    emergencyContactName: new FormControl(null, [Validators.pattern('^[a-zA-Z ]*$')]),
    emergencyContactPhone: new FormControl(null),
    emergencyContactRelationShip: new FormControl(null),
    mbi: new FormControl(null, Validators.required),
    medicareEffectiveDatePartA: new FormControl(null),
    medicareEffectiveDatePartB: new FormControl(null),
    isCoverage: new FormControl(null, [Validators.required]),
    coverageName: new FormControl(null),
    coverageId: new FormControl(null),
    coverageGroup: new FormControl(null),
    isMedicaid: new FormControl(false, [Validators.required]),
    medicaidnumber: new FormControl({ value: '', disabled: true }),
    PCPId: new FormControl('', [Validators.pattern('^[0-9]*$')]),
    PCPCurrentPatient: new FormControl(null),
    Diabetes1: new FormControl(null),
    Diabetes2: new FormControl(null),
    Cardiovascular1: new FormControl(null),
    Cardiovascular2: new FormControl(null),
    Cardiovascular3: new FormControl(null),
    Dialysis1: new FormControl(null),
    Dialysis2: new FormControl(null),
    authorizedPersonSignature: new FormControl(null, [Validators.required]),
    proposedEffectiveDate: new FormControl(null, [Validators.required]),
    todaysDate: new FormControl(this.todayDate, [Validators.required]),
    authorizedPersonName: new FormControl(null, [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]),
    authorizedPersonRelationshiptoEnrollee: new FormControl(null),
    authorizedPersonAddress: new FormControl(null, Validators.required),
    authorizedPersonPhoneNumber: new FormControl(null, [Validators.required, Validators.minLength(10), Validators.maxLength(10)])
  });

  standAloneForm2 = new FormGroup({
    race: new FormControl(null),
    ethnicity: new FormControl(null),
    partDAmount: new FormControl(null, [Validators.required]),
    benefitedBy: new FormControl(null, [Validators.required]),
    accessibilityFormatLanguage: new FormControl(null),
    accessibilityFormatFontSize: new FormControl(accessibilityFormatFontSize.Default, Validators.required),
    foundGoldKidney: new FormControl(null)
  });

  standAloneForm3 = this.fb.group({
    SEPID: new FormControl(null, Validators.required),
    SEPDate: new FormControl(''),
    salesAgentId: new FormControl(null),
    salesAgentName: new FormControl(null, [Validators.maxLength(20), Validators.required, Validators.pattern('^[a-zA-Z. ]*$')]),
    salesDate: new FormControl(null),
    sourceCode: new FormControl(null),
    location: new FormControl(null),
    ICEP_IEP: new FormControl(null),
    AEP: new FormControl(null),
    SEP: new FormControl(null),
    electionPeriod: new FormControl(null),
    scopeOfSeminar: new FormControl(null),
  });

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private standAloneService: StandAloneService,
    private authService: AuthService
  ) {

    var validateToken = this.authService.getToken();

    if (Utils.isBlank(validateToken)) {
      this.standAloneService.getAccessToken()
        .subscribe({
          next: (res) => {
            if (!Utils.isBlank(res)) {
              Utils.removeAccessTokenValues();
              Utils.setAccessTokenValues(res);
              this.initialAllPropertiesAndMethods();
            }
          }, error: (err) => {
            console.log(err);
          }
        });
    } else {
      this.initialAllPropertiesAndMethods();
    }
  }

  initialAllPropertiesAndMethods(): void {
    this.bindCommonCodeList();
    this.todayDate = new Date();


    var y = this.todayDate.getFullYear(), m = this.todayDate.getMonth(), d = this.todayDate.getDate() - 1;
    this.YesterdayDate.setDate(this.todayDate.getDate() - 1);
    var firstDay = new Date(y, m + 1, 1);

    this.standAloneForm1.controls["proposedEffectiveDate"].setValue(firstDay);

    this.contractList = [];
    this.PBPList = [];
    this.raceList = [];
    this.ethnicityList = [];
    this.emergencyContactRelationshipList = [];
    this.contactTypeList = [];
    this.genderList = [];
    this.initialsList = [];
    this.finalQuestionnaire = [];
  }

  get form(): { [key: string]: AbstractControl; } {
    return this.standAloneForm1.controls;
  }
  get form2(): { [key: string]: AbstractControl; } {
    return this.standAloneForm2.controls;
  }
  get form3(): { [key: string]: AbstractControl; } {
    return this.standAloneForm3.controls;
  }

  ngOnInit(): void {
    this.tPbpIDs = [];
    this.form['permanentAddressZipCode'].valueChanges.pipe(
      filter(res => res?.length > 4)
      , debounceTime(1000)
      , distinctUntilChanged()
    ).subscribe((text: string) => {
      this.standAloneService.getZipCodesDetails(text).subscribe((res) => {
        if (!Utils.isBlank(res)) {
          this.standAloneForm1.controls["permanentAddressCity"].setValue(res.city);
          this.standAloneForm1.controls["permanentAddressState"].setValue(res.state);
        } else {
          this.standAloneForm1.controls["permanentAddressCity"].setValue(null);
          this.standAloneForm1.controls["permanentAddressState"].setValue(null);
        }
      }, (err) => {
        console.log('error', err);
      });
    });


    this.form['mailingAddressZipCode'].valueChanges.pipe(
      filter(res => res?.length > 4)
      , debounceTime(1000)
      , distinctUntilChanged()
    ).subscribe((text: string) => {
      this.standAloneService.getZipCodesDetails(text).subscribe((res) => {
        if (!Utils.isBlank(res)) {
          this.standAloneForm1.controls["mailingAddressCity"].setValue(res.city);
          this.standAloneForm1.controls["mailingAddressState"].setValue(res.state);
        } else {
          this.standAloneForm1.controls["mailingAddressCity"].setValue(null);
          this.standAloneForm1.controls["mailingAddressState"].setValue(null);
        }
      }, (err) => {
        console.log('error', err);
      });
      if (Utils.isBlank(this.standAloneForm1.get('mailingAddress')?.value) && !Utils.isBlank(text)) {
        this.mailZipCodeValid = false;
      }
      else {
        this.mailZipCodeValid = true;
      }
    });

    this.form['mailingAddress'].valueChanges.subscribe(data => {
      if (Utils.isBlank(data) && !Utils.isBlank(this.standAloneForm1.get('mailingAddressZipCode')?.value)) {
        this.mailZipCodeValid = false;
      }
      else {
        this.mailZipCodeValid = true;
      }
    });

    this.form['permanentAddress'].valueChanges.subscribe(data => {
      if (!Utils.isBlank(data)) {
        let arr = ["pobox", "p.obox", "po.box", "p.o.box", "postofficebox"];
        if (arr.indexOf(data.replace(/\s/g, '').toLowerCase()) > -1) {
          this.isPA1Valid = false;
        } else {
          this.isPA1Valid = true;
        }
      } else {
        this.isPA1Valid = true
      }
    });

    this.form['medicareEffectiveDatePartA'].valueChanges.subscribe(data => {
      let firstDateOfMonth = new Date(data).getDate();
      let DOB = this.standAloneForm1.get('dob')?.value;
      if (firstDateOfMonth != 1 || data < DOB) {
        this.partADateValid = false;
      } else {
        this.partADateValid = true;
      }
    });

    this.form['medicareEffectiveDatePartB'].valueChanges.subscribe(data => {
      let firstDateOfMonth = new Date(data).getDate();
      let DOB = this.standAloneForm1.get('dob')?.value;
      if (firstDateOfMonth != 1 || data < DOB) {
        this.partBDateValid = false;
      } else {
        this.partBDateValid = true;
      }
    });


    this.form3['salesAgentId'].valueChanges.pipe(
      filter(res => res?.length > 0)
      , debounceTime(1000)
      , distinctUntilChanged(),
    ).subscribe((text: string) => {
      this.standAloneService.GetProviderNameByProCode(text).subscribe({
        next: (res) => {
          if (!Utils.isBlank(res)) {
            let a = res.firstName + ' ' + res.middleName + ' ' + res.lastName;
            this.standAloneForm3.controls["salesAgentName"].setValue(a);
          } else {
            this.standAloneForm3.controls["salesAgentName"].setValue(null);
          }
        },
        error: (err) => {
          // console.log('error', err);
          this.standAloneForm3.controls["salesAgentName"].setValue(null);
          this.openDialog('', AppConstant.textOkConfirm, '', null, AppConstant.agentIfInvaildMessage, 'yes', "salesAgentId");
        }
      });
    });

  }
  medicaidEnableDisable() {
    const isMedicaidControl = this.standAloneForm1.get('isMedicaid');
    const medicaidNumberControl = this.standAloneForm1.get('medicaidnumber');

    if (isMedicaidControl?.value === true) {
      // If "Yes" is selected, enable the Medicaid number field
      medicaidNumberControl?.enable();
    } else {
      // If "No" is selected, disable the Medicaid number field
      medicaidNumberControl?.disable();
    }
    this.standAloneForm1.controls["medicaidnumber"].setValue(null);
  }
  // Switch Section Function starts 
  changeSection(section: number) {
    if (section == 1) {
      console.log('section', section);
      this.activeSection = section;
    }
    else {
      if (section == 2) {
        if (this.standAloneForm1.status == "VALID") {
          console.log('section', section);
          console.log('this.standAloneForm1', this.standAloneForm1);
          this.activeSection = section;
        }
      }
      else {
        if (section == 3) {
          if (this.standAloneForm2.status == "VALID") {
            console.log('section', section);
            console.log('this.standAloneForm2', this.standAloneForm2);
            this.activeSection = section;
          }
        }
      }
    }
  }
  // Switch Section Function ends

  //HealthPlan, Gender, Salutation, RelationShip, Lists API callin function starts

  bindCommonCodeList() {
    // this.isLoadingData = false;
    this.standAloneService.getPBPByCodeTypeId(CodeType.CMSPBPCode).subscribe((result) => {
      this.PBPList = result;
      let contactType = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.HIPAACommunication);
      let emergencyContactRelationship = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.MemberRelationship);
      let contract = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.CMSContractCode);

      let race = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.Race);
      let ethnicity = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.Ethnicity);
      let gender = this.standAloneService.getCommonCodeConfigurationByCodeTypeId(Page.ENROLLMENT_PAGE.toString(), CodeType.Gender);
      let initials = this.standAloneService.getCommonCodeByCodeTypeId(CodeType.Prefix);
      let question = this.standAloneService.getSepReason();

      forkJoin([contactType, emergencyContactRelationship, contract, gender, initials, question, race, ethnicity]).subscribe({
        next: (res) => {
          this.contactTypeList = res[0];
          this.emergencyContactRelationshipList = res[1];
          this.contractList = res[2];

          this.genderList = res[3];
          this.initialsList = res[4];
          this.finalQuestionnaire = res[5];
          this.raceList = res[6];
          this.ethnicityList = res[7];
          this.contactTypeList.forEach(element => {
            if (element.commonCodeID == 5902) {
              element.checked = true;
            }
            else {
              element.checked = false;
            }
          });
          this.finalQuestionnaire.forEach(element => {
            element.checked = false;
          });
        }, error: (err) => {
          // this.isLoadingData = true;
          console.log(err);
        }
      });
    });

  }

  //HealthPlan, Gender, Salutation, RelationShip, Lists API callin function ends

  // Sections 1 Functions ends


  planTypeCheckBox(planId: any) {
    // this.PBPList.forEach(element => {
    //   if (element.commonCodeID == planId) {
    //     element.checked = true;
    //   }
    //   else {
    //     element.checked = false;
    //   }
    // });

    this.standAloneForm1.controls["contractType"].setValue(this.contractList[0].commonCodeID);
    this.standAloneForm1.controls["planType"].setValue(planId);
    // console.log('this.standAloneForm1', this.standAloneForm1);
    const checkboxLabelMapping: { [id: string]: string } = {
      51601: 'Gold Kidney Super Plus',
      51602: 'Gold Kidney Super Complete',
      51603: 'Gold Kidney Dialysis Plus',
      51604: 'Gold Kidney Dialysis Complete',
      51605: 'Gold Kidney Honest Care'
    };
    if (!this.planTypeVal) {
      this.planTypeVal = checkboxLabelMapping[planId];
    } else {
      const labels = this.planTypeVal.split(','); // Split the string into an array
      const labelToAdd = checkboxLabelMapping[planId];
      const index = labels.indexOf(labelToAdd);

      if (index !== -1) {
        labels.splice(index, 1); // Remove the label from the array
      } else {
        labels.push(labelToAdd); // Add the label to the array
      }

      this.planTypeVal = labels.join(','); // Join the array back into a string
    }
  }
  // Select Initials Function Starts

  selectInitials(event: any) {
    this.standAloneForm1.controls["initials"].setValue(event);
    if (event == 5201 || event == 5203) {
      this.checkedGenderValue(event);
      this.standAloneForm1.controls["gender"].setValue(10003);
    }
    else if (event == 5202) {
      this.checkedGenderValue(event);
      this.standAloneForm1.controls["gender"].setValue(10002);
    }
  }

  // Select Initials Function ends

  //Checked the Gender radio button based on prefix selection function starts
  checkedGenderValue(event: any) {
    return this.standAloneForm1.get('gender')?.value == event;
  }

  //Checked the Gender radio button based on prefix selection function starts

  // Select Gender Function Starts

  selectGender(event: any) {
    this.standAloneForm1.controls["gender"].setValue(event);
  }

  // Select Gender Function ends

  // Contact Prfrences Function starts

  contactPrefrenceCheckUncheck(event: any) {
    event.checked = !event.checked;
    if (event.commonCodeID == 5901 && event.checked) {
      this.emailAddress.nativeElement.focus();
      this.emailRequired();
    }
    else {
      this.removeEmailRequired();
    }
    let a = '';
    this.contactTypeList.forEach(element => {
      if (element.checked) {
        a = a + element.commonCodeID + ',';
      }
    });

    a = a.substring(0, a.length - 1);
    this.standAloneForm1.controls["contactPrefrence"].setValue(a);
  }

  emailRequired() {
    this.standAloneForm1.controls["emailAddress"].markAsTouched();
    this.standAloneForm1.controls["emailAddress"].setValidators([Validators.required]);
    this.standAloneForm1.controls["emailAddress"].updateValueAndValidity();
  }

  removeEmailRequired() {
    this.standAloneForm1.controls["emailAddress"].clearValidators();
    this.standAloneForm1.controls["emailAddress"].updateValueAndValidity();
  }
  // Contact Prfrences Function ends

  // Mailing addresss Function starts

  addressCheckBox(val: any) {
    this.mailingAddressReadonly = !val;
    this.standAloneForm1.controls["mailingAddress"].setValue(null);
    this.standAloneForm1.controls["mailingAddressCity"].setValue(null);
    this.standAloneForm1.controls["mailingAddressState"].setValue(null);
    this.standAloneForm1.controls["mailingAddressZipCode"].setValue(null);
    this.mailZipCodeValid = true;
  }

  // Mailing addresss Function ends

  // MBI Functions starts

  // MBI On focus Out Functions starts

  onFocusOutMbiEvent(event: any): void {
    if (!Utils.isBlank(event) && !Utils.isBlank(event.currentTarget.value)) {
      let mbiValue: string = event.currentTarget.value;
      if (!Utils.isMbiNumberValid(mbiValue)) {
        // this.confirmMbiNumber();
        this.openDialog('', AppConstant.textYesConfirm, AppConstant.textNoConfirm, null, AppConstant.mbiValidationMessage, 'both', event.currentTarget.id);
      }
    }
  }
  // MBI On focus Out Functions ends 

  // Confirm Dialog Box open Functions starts

  public openDialog(title: string, textYes: string = '', textNo: string = '', item: any, message: string, buttonType: string, inputType: any): void {
    const dialogRef = this.dialog.open(CustomConfirmDialogComponent, {
      width: '350px',
      data: {
        title: title,
        textYes: textYes,
        textNo: textNo,
        item: item,
        message: message,
        buttonType: buttonType,
      } as CustomConfimDialogModel,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (inputType == 'mbiInput') {
          this.mbiInput.nativeElement.focus();
        }
        else {
          if (inputType == 'medicaidInput') {
            this.medicaidInput.nativeElement.focus();
          }
          else {
            if (inputType == 'salesAgentId') {
              this.salesAgentIdInput.nativeElement.focus();
            }
          }
        }
        // } else {
        //   if(inputType == 'mbiInput')
        //   {
        //     this.mbiInput.nativeElement.focusout();
        //   }
        //   else
        //   {
        //     this.medicaidInput.nativeElement.focusout();            
        //   }
      }
    });
  }

  // Confirm Dialog Box open Functions ends

  // Set MBI Value Functions starts

  onChangeMbiEvent(event: any): void {
    this.standAloneForm1.controls["mbi"].setValue(event.target.value);
  }

  // Set MBI Value Functions ends

  // MBI Functions ends

  // Other Drugs Coverage checkbox Value function starts

  coverageEnableDisable() {
    this.standAloneForm1.controls["coverageName"].setValue(null);
    this.standAloneForm1.controls["coverageId"].setValue(null);
    this.standAloneForm1.controls["coverageGroup"].setValue(null);
  }

  // Other Drugs Coverage checkbox Value function ends

  // medicaid checkbox Value function ends


  // medicaid checkbox Value function ends

  //Medicade On focus Out Functions starts
  onFocusOutMedicaidEvent(event: any): void {
    let mbiValue = this.standAloneForm1.controls['mbi'].value;
    if (!Utils.isBlank(event) && !Utils.isBlank(event.currentTarget.value)) {
      let Value: string = event.currentTarget.value;
      if (Value == mbiValue) {
        this.openDialog('', AppConstant.textOkConfirm, '', null, AppConstant.mbiMedicaidErrorMessage, 'yes', event.currentTarget.id);
      }
    }
  }

  //Medicade On focus Out Functions ends

  // Sections 1 Functions ends

  // Sections 3 Functions starts

  benefitedBy(value: string) {
    this.standAloneForm2.controls["benefitedBy"].setValue(value);
    this.checkedBenefitedBy = value;
  }
  foundGoldKidneyChecked(value: string) {
    this.standAloneForm2.controls["foundGoldKidney"].setValue(value);
    this.checkedfoundGoldKidney = value;
  }
  updateSelectedValues(event: MatCheckboxChange, value: string) {
    const selectedValuesControl = this.standAloneForm2.get('foundGoldKidney');
    const selectedValues = selectedValuesControl?.value || '';

    if (event.checked) {
      // Add the value if the checkbox is checked
      selectedValuesControl?.setValue(selectedValues + (selectedValues ? ',' : '') + value);
    } else {
      // Remove the value if the checkbox is unchecked
      const valuesArray = selectedValues.split(',');
      const index = valuesArray.indexOf(value);
      if (index !== -1) {
        valuesArray.splice(index, 1);
        selectedValuesControl?.setValue(valuesArray.join(','));
      }
    }
    if (this.selectedValues.includes(value)) {
      // Remove the value if it's already selected
      const index = this.selectedValues.indexOf(value);
      this.selectedValues.splice(index, 1);
    } else {
      // Add the value if it's not selected
      this.selectedValues.push(value);
    }
    this.finalFound = selectedValuesControl;
  }
  updateSelectedPrintValues(event: MatCheckboxChange, value: string) {
    const selectedValuesControl = this.standAloneForm2.get('accessibilityFormatLanguage');
    const selectedPrintValues = selectedValuesControl?.value || '';

    if (event.checked) {
      // Add the value if the checkbox is checked
      selectedValuesControl?.setValue(selectedPrintValues + (selectedPrintValues ? ',' : '') + value);
    } else {
      // Remove the value if the checkbox is unchecked
      const valuesArray = selectedPrintValues.split(',');
      const index = valuesArray.indexOf(value);
      if (index !== -1) {
        valuesArray.splice(index, 1);
        selectedValuesControl?.setValue(valuesArray.join(','));
      }
    }
    if (this.selectedPrintValues.includes(value)) {
      // Remove the value if it's already selected
      const index = this.selectedPrintValues.indexOf(value);
      this.selectedPrintValues.splice(index, 1);
    } else {
      // Add the value if it's not selected
      this.selectedPrintValues.push(value);
    }
    this.finalPrintFound = selectedValuesControl;
  }
  isChecked(value: string) {
    return this.selectedValues.includes(value);
  }
  isPrintChecked(value: string) {
    return this.selectedPrintValues.includes(value);
  }
  accessibilityFormatLanguage(language: string) {
    this.standAloneForm2.controls["accessibilityFormatLanguage"].setValue(language);
  }

  accessibilityFormatFontSize() {
    // this.standAloneForm2.controls["accessibilityFormatFontSize"].setValue('Large');
  }

  checkUncheckQuestionnaire(sepReasonCodeID: any) {
    this.standAloneForm3.controls["SEPDate"].setValue(null);
    this.finalQuestionnaire.forEach(element => {
      if (element.sepReasonCodeID == sepReasonCodeID) {
        element.checked = !element.checked;
        if (element.checked) {
          if (element.dateToBeEntered) {
            this.dateEnable = false;
          }
          else {
            this.dateEnable = true;
          }
        }
        else {
          this.dateEnable = true;
        }
      }
      else {
        element.checked = false;
      }
    });

    this.standAloneForm3.controls["SEPID"].setValue(sepReasonCodeID);
  }

  SEPDateChange() {
    this.dateEnable = true;
  }

  // Sections 3 Functions ends

  clearAllForm(Value: number) {
    if (Value == 1) {
      this.tPbpIDs = [];
      this.standAloneForm1.controls["contractType"].setValue(null);
      this.standAloneForm1.controls["planType"].setValue(null);
      this.standAloneForm1.controls["initials"].setValue(null);
      this.standAloneForm1.controls["firstName"].setValue(null);
      this.standAloneForm1.controls["lastName"].setValue(null);
      this.standAloneForm1.controls["middleName"].setValue(null);
      this.standAloneForm1.controls["dob"].setValue(null);
      this.standAloneForm1.controls["gender"].setValue(null);
      this.standAloneForm1.controls["homePhoneNo"].setValue(null);
      this.standAloneForm1.controls["cellPhoneNo"].setValue(null);
      this.standAloneForm1.controls["emailAddress"].setValue(null);
      this.standAloneForm1.controls["contactPrefrence"].setValue(null);
      this.standAloneForm1.controls["permanentAddress"].setValue(null);
      this.standAloneForm1.controls["permanentAddressCity"].setValue(null);
      this.standAloneForm1.controls["permanentAddressState"].setValue(null);
      this.standAloneForm1.controls["permanentAddressZipCode"].setValue(null);
      this.standAloneForm1.controls["mailingAddress"].setValue(null);
      this.standAloneForm1.controls["mailingAddressCity"].setValue(null);
      this.standAloneForm1.controls["mailingAddressState"].setValue(null);
      this.standAloneForm1.controls["mailingAddressZipCode"].setValue(null);
      this.standAloneForm1.controls["emergencyContactName"].setValue(null);
      this.standAloneForm1.controls["emergencyContactPhone"].setValue(null);
      this.standAloneForm1.controls["emergencyContactRelationShip"].setValue(null);
      this.standAloneForm1.controls["mbi"].setValue(null);
      this.standAloneForm1.controls["medicareEffectiveDatePartA"].setValue(null);
      this.standAloneForm1.controls["medicareEffectiveDatePartB"].setValue(null);
      this.standAloneForm1.controls["isCoverage"].setValue(null);
      this.standAloneForm1.controls["coverageName"].setValue(null);
      this.standAloneForm1.controls["coverageId"].setValue(null);
      this.standAloneForm1.controls["coverageGroup"].setValue(null);
      this.standAloneForm1.controls["isMedicaid"].setValue(null);
      this.standAloneForm1.controls["medicaidnumber"].setValue(null);
      this.standAloneForm1.controls["PCPName"].setValue(null);
      this.standAloneForm1.controls["NepName"].setValue(null);
      this.standAloneForm1.controls["NepPhoneNumber"].setValue(null);
      this.standAloneForm1.controls["NepCity"].setValue(null);
      this.standAloneForm1.controls["Diabetes1"].setValue(null);
      this.standAloneForm1.controls["Diabetes2"].setValue(null);
      this.standAloneForm1.controls["Cardiovascular1"].setValue(null);
      this.standAloneForm1.controls["Cardiovascular2"].setValue(null);
      this.standAloneForm1.controls["Cardiovascular3"].setValue(null);
      this.standAloneForm1.controls["Dialysis1"].setValue(null);
      this.standAloneForm1.controls["Dialysis2"].setValue(null);
      this.standAloneForm1.controls["speciality"].setValue(null);
      this.standAloneForm1.controls["phoneNumber"].setValue(null);
      this.standAloneForm1.controls["medicalGroup"].setValue(null);
      this.standAloneForm1.controls["city"].setValue(null);
      this.standAloneForm1.controls["PCPName2"].setValue(null);
      this.standAloneForm1.controls["PCPName3"].setValue(null);
      this.standAloneForm1.controls["speciality2"].setValue(null);
      this.standAloneForm1.controls["speciality3"].setValue(null);
      this.standAloneForm1.controls["city2"].setValue(null);
      this.standAloneForm1.controls["city3"].setValue(null);
      this.standAloneForm1.controls["phoneNumber2"].setValue(null);
      this.standAloneForm1.controls["phoneNumber3"].setValue(null);
      this.standAloneForm1.controls["faxNumber2"].setValue(null);
      this.standAloneForm1.controls["faxNumber3"].setValue(null);
      this.standAloneForm1.controls["PCPId"].setValue(null);
      this.standAloneForm1.controls["PCPCurrentPatient"].setValue(null);
      this.standAloneForm1.controls["authorizedPersonSignature"].setValue(null);
      var y = this.todayDate.getFullYear(), m = this.todayDate.getMonth();
      var firstDay = new Date(y, m + 1, 1);

      this.standAloneForm1.controls["proposedEffectiveDate"].setValue(firstDay);
      this.standAloneForm1.controls["todaysDate"].setValue(this.todayDate);
      this.standAloneForm1.controls["authorizedPersonName"].setValue(null);
      this.standAloneForm1.controls["authorizedPersonRelationshiptoEnrollee"].setValue(null);
      this.standAloneForm1.controls["authorizedPersonAddress"].setValue(null);
      this.standAloneForm1.controls["authorizedPersonPhoneNumber"].setValue(null);
    }
    else {
      if (Value == 2) {

        this.standAloneForm2.controls["partDAmount"].setValue(null);
        this.standAloneForm2.controls["race"].setValue(null);
        this.standAloneForm2.controls["ethnicity"].setValue(null);
        this.standAloneForm2.controls["benefitedBy"].setValue(null);
        this.standAloneForm2.controls["foundGoldKidney"].setValue(null);
        this.standAloneForm2.controls["accessibilityFormatLanguage"].setValue(accessibilityFormatLanguage.Default);
        this.standAloneForm2.controls["accessibilityFormatFontSize"].setValue(accessibilityFormatFontSize.Default);
      }
      else {
        if (Value == 3) {
          this.standAloneForm3.controls["SEPID"].setValue(null);
          this.standAloneForm3.controls["SEPDate"].setValue(null);
          this.standAloneForm3.controls["salesAgentId"].setValue(null);
          this.standAloneForm3.controls["salesAgentName"].setValue(null);
          this.standAloneForm3.controls["salesDate"].setValue(null);
          this.standAloneForm3.controls["sourceCode"].setValue(null);
          this.standAloneForm3.controls["location"].setValue(null);
          this.standAloneForm3.controls["electionPeriod"].setValue(null);
          this.standAloneForm3.controls["scopeOfSeminar"].setValue(null);

          this.checkedBenefitedBy = "";
          this.checkUncheckQuestionnaire(0)
        }
        else {
          this.tPbpIDs = [];
          this.standAloneForm1.controls["contractType"].setValue(null);
          this.standAloneForm1.controls["planType"].setValue(null);
          this.standAloneForm2.controls["race"].setValue(null);
          this.standAloneForm2.controls["ethnicity"].setValue(null);
          this.standAloneForm1.controls["initials"].setValue(null);
          this.standAloneForm1.controls["firstName"].setValue(null);
          this.standAloneForm1.controls["lastName"].setValue(null);
          this.standAloneForm1.controls["middleName"].setValue(null);
          this.standAloneForm1.controls["dob"].setValue(null);
          this.standAloneForm1.controls["gender"].setValue(null);
          this.standAloneForm1.controls["homePhoneNo"].setValue(null);
          this.standAloneForm1.controls["cellPhoneNo"].setValue(null);
          this.standAloneForm1.controls["emailAddress"].setValue(null);
          this.standAloneForm1.controls["contactPrefrence"].setValue(null);
          this.standAloneForm1.controls["permanentAddress"].setValue(null);
          this.standAloneForm1.controls["permanentAddressCity"].setValue(null);
          this.standAloneForm1.controls["permanentAddressState"].setValue(null);
          this.standAloneForm1.controls["permanentAddressZipCode"].setValue(null);
          this.standAloneForm1.controls["mailingAddress"].setValue(null);
          this.standAloneForm1.controls["mailingAddressCity"].setValue(null);
          this.standAloneForm1.controls["mailingAddressState"].setValue(null);
          this.standAloneForm1.controls["mailingAddressZipCode"].setValue(null);
          this.standAloneForm1.controls["emergencyContactName"].setValue(null);
          this.standAloneForm1.controls["emergencyContactPhone"].setValue(null);
          this.standAloneForm1.controls["emergencyContactRelationShip"].setValue(null);
          this.standAloneForm1.controls["mbi"].setValue(null);
          this.standAloneForm1.controls["medicareEffectiveDatePartA"].setValue(null);
          this.standAloneForm1.controls["medicareEffectiveDatePartB"].setValue(null);
          this.standAloneForm1.controls["isCoverage"].setValue(null);
          this.standAloneForm1.controls["coverageName"].setValue(null);
          this.standAloneForm1.controls["coverageId"].setValue(null);
          this.standAloneForm1.controls["coverageGroup"].setValue(null);
          this.standAloneForm1.controls["isMedicaid"].setValue(null);
          this.standAloneForm1.controls["medicaidnumber"].setValue(null);
          this.standAloneForm1.controls["speciality"].setValue(null);
          this.standAloneForm1.controls["phoneNumber"].setValue(null);
          this.standAloneForm1.controls["medicalGroup"].setValue(null);
          this.standAloneForm1.controls["city"].setValue(null);

          var y = this.todayDate.getFullYear(), m = this.todayDate.getMonth();
          var firstDay = new Date(y, m + 1, 1);

          this.standAloneForm1.controls["authorizedPersonSignature"].setValue(null);
          this.standAloneForm1.controls["proposedEffectiveDate"].setValue(firstDay);
          this.standAloneForm1.controls["todaysDate"].setValue(this.todayDate);
          this.standAloneForm1.controls["authorizedPersonName"].setValue(null);
          this.standAloneForm1.controls["authorizedPersonRelationshiptoEnrollee"].setValue(null);
          this.standAloneForm1.controls["authorizedPersonAddress"].setValue(null);
          this.standAloneForm1.controls["authorizedPersonPhoneNumber"].setValue(null);
          this.standAloneForm1.controls["Diabetes1"].setValue(null);
          this.standAloneForm1.controls["Diabetes2"].setValue(null);
          this.standAloneForm1.controls["Cardiovascular1"].setValue(null);
          this.standAloneForm1.controls["Cardiovascular2"].setValue(null);
          this.standAloneForm1.controls["Cardiovascular3"].setValue(null);
          this.standAloneForm1.controls["Dialysis1"].setValue(null);
          this.standAloneForm1.controls["Dialysis2"].setValue(null);
          this.standAloneForm2.controls["partDAmount"].setValue(null);
          this.standAloneForm2.controls["benefitedBy"].setValue(null);
          this.standAloneForm2.controls["foundGoldKidney"].setValue(null);
          this.standAloneForm1.controls["PCPName"].setValue(null);
          this.standAloneForm1.controls["NepName"].setValue(null);
          this.standAloneForm1.controls["NepPhoneNumber"].setValue(null);
          this.standAloneForm1.controls["NepCity"].setValue(null);
          this.standAloneForm1.controls["PCPName2"].setValue(null);
          this.standAloneForm1.controls["PCPName3"].setValue(null);
          this.standAloneForm1.controls["speciality2"].setValue(null);
          this.standAloneForm1.controls["speciality3"].setValue(null);
          this.standAloneForm1.controls["city2"].setValue(null);
          this.standAloneForm1.controls["city3"].setValue(null);
          this.standAloneForm1.controls["phoneNumber2"].setValue(null);
          this.standAloneForm1.controls["phoneNumber3"].setValue(null);
          this.standAloneForm1.controls["faxNumber2"].setValue(null);
          this.standAloneForm1.controls["faxNumber3"].setValue(null);
          this.standAloneForm1.controls["PCPId"].setValue(null);
          this.standAloneForm1.controls["PCPCurrentPatient"].setValue(null);
          this.standAloneForm2.controls["accessibilityFormatLanguage"].setValue(accessibilityFormatLanguage.Default);
          this.standAloneForm2.controls["accessibilityFormatFontSize"].setValue(accessibilityFormatFontSize.Default);

          this.standAloneForm3.controls["SEPID"].setValue(null);
          this.standAloneForm3.controls["SEPDate"].setValue(null);
          this.standAloneForm3.controls["salesAgentId"].setValue(null);
          this.standAloneForm3.controls["salesAgentName"].setValue(null);
          this.standAloneForm3.controls["salesDate"].setValue(null);
          this.standAloneForm3.controls["sourceCode"].setValue(null);
          this.standAloneForm3.controls["location"].setValue(null);
          this.standAloneForm3.controls["electionPeriod"].setValue(null);
          this.standAloneForm3.controls["scopeOfSeminar"].setValue(null);

          this.checkedBenefitedBy = "";
          this.checkUncheckQuestionnaire(0)

          this.activeSection = 1;
          this.ngOnInit();
        }
      }
    }
  }

  submit() {
    if (this.standAloneForm1.status == "VALID" && this.standAloneForm2.status == "VALID" && this.standAloneForm3.status == "VALID") {
      this.PreEnrollmentObj = this.preEnrollmentMemberDataMapper();

      this.PreEnrollmentObj.foundGoldKidney = Utils.isBlank(this.finalFound.value) ? "" : this.finalFound.value;
      this.standAloneForm2.get('foundGoldKidney')?.setValue(null);

      this.PreEnrollmentObj.AccessibilityFormatLanguage = Utils.isBlank(this.finalPrintFound.value) ? "" : this.finalPrintFound.value;
      this.standAloneForm2.get('accessibilityFormatLanguage')?.setValue(null);

      this.standAloneService.InsertPreEnrollmentMember(this.PreEnrollmentObj)
        .subscribe({
          next: (res) => {
            alert("New Enrollment Member Created");
            this.clearAllForm(0);
            window.location.reload();
          }, error: (err) => {
            console.log(err);
          }
        })
    } else {
      alert('issue');
    }
  }

  preEnrollmentMemberDataMapper() {
    let PreEnrollmentData = new PreEnrollmentModel();

    PreEnrollmentData.ContractId = Utils.isBlank(this.standAloneForm1.value.contractType) ? 51501 : this.standAloneForm1.value.contractType;
    PreEnrollmentData.PBPId = Utils.isBlank(this.standAloneForm1.value.planType) ? 0 : Number(this.standAloneForm1.value.planType);
    PreEnrollmentData.PlanType = Utils.isBlank(this.standAloneForm1.value.planType) ? 0 : Number(this.standAloneForm1.value.planType);
    PreEnrollmentData.RaceID = Utils.isBlank(this.standAloneForm2.value.race) ? 0 : Number(this.standAloneForm2.value.race);
    PreEnrollmentData.EthnicityID = Utils.isBlank(this.standAloneForm2.value.ethnicity) ? 0 : Number(this.standAloneForm2.value.ethnicity);
    PreEnrollmentData.Prefix = Utils.isBlank(this.standAloneForm1.value.initials) ? "" : this.standAloneForm1.value.initials;
    PreEnrollmentData.FirstName = Utils.isBlank(this.standAloneForm1.value.firstName) ? "" : this.standAloneForm1.value.firstName;
    PreEnrollmentData.ICEP_IEP = Utils.isBlank(this.standAloneForm3.value.ICEP_IEP) ? "" : this.standAloneForm3.value.ICEP_IEP;
    PreEnrollmentData.AEP = Utils.isBlank(this.standAloneForm3.value.AEP) ? "" : this.standAloneForm3.value.AEP;
    PreEnrollmentData.SEP = Utils.isBlank(this.standAloneForm3.value.SEP) ? "" : this.standAloneForm3.value.SEP;
    PreEnrollmentData.LastName = Utils.isBlank(this.standAloneForm1.value.lastName) ? "" : this.standAloneForm1.value.lastName;
    PreEnrollmentData.MiddleName = Utils.isBlank(this.standAloneForm1.value.middleName) ? "" : this.standAloneForm1.value.middleName;
    PreEnrollmentData.DOB = Utils.isBlank(this.standAloneForm1.value.dob) ? null : this.standAloneForm1.value.dob;
    PreEnrollmentData.GenderId = Utils.isBlank(this.standAloneForm1.value.gender) ? 0 : Number(this.standAloneForm1.value.gender);
    PreEnrollmentData.HomePhoneNo = Utils.isBlank(this.standAloneForm1.value.homePhoneNo) ? "" : this.standAloneForm1.value.homePhoneNo;
    PreEnrollmentData.lobid = Utils.isBlank(this.lobid) ? 123 : this.lobid;
    PreEnrollmentData.CellPhoneNo = Utils.isBlank(this.standAloneForm1.value.cellPhoneNo) ? "" : this.standAloneForm1.value.cellPhoneNo;
    PreEnrollmentData.EmailAddress = Utils.isBlank(this.standAloneForm1.value.emailAddress) ? "" : this.standAloneForm1.value.emailAddress;
    PreEnrollmentData.ContactPrefrence = Utils.isBlank(this.standAloneForm1.value.contactPrefrence) ? "" : this.standAloneForm1.value.contactPrefrence;
    PreEnrollmentData.PermanentAddressLine1 = Utils.isBlank(this.standAloneForm1.value.permanentAddress) ? "" : this.standAloneForm1.value.permanentAddress;
    PreEnrollmentData.PermanentAddressCity = Utils.isBlank(this.standAloneForm1.value.permanentAddressCity) ? "" : this.standAloneForm1.value.permanentAddressCity;
    PreEnrollmentData.PermanentAddressState = Utils.isBlank(this.standAloneForm1.value.permanentAddressState) ? "" : this.standAloneForm1.value.permanentAddressState;
    PreEnrollmentData.PermanentAddressZip = Utils.isBlank(this.standAloneForm1.value.permanentAddressZipCode) ? "" : this.standAloneForm1.value.permanentAddressZipCode;
    PreEnrollmentData.MailingAddress = Utils.isBlank(this.standAloneForm1.value.mailingAddress) ? "" : this.standAloneForm1.value.mailingAddress;
    PreEnrollmentData.MailingAddressCity = Utils.isBlank(this.standAloneForm1.value.mailingAddressCity) ? "" : this.standAloneForm1.value.mailingAddressCity;
    PreEnrollmentData.MailingAddressState = Utils.isBlank(this.standAloneForm1.value.mailingAddressState) ? "" : this.standAloneForm1.value.mailingAddressState;
    PreEnrollmentData.MailingAddressZipCode = Utils.isBlank(this.standAloneForm1.value.mailingAddressZipCode) ? "" : this.standAloneForm1.value.mailingAddressZipCode;
    PreEnrollmentData.EmergencyContactName = Utils.isBlank(this.standAloneForm1.value.emergencyContactName) ? "" : this.standAloneForm1.value.emergencyContactName;
    PreEnrollmentData.EmergencyContactPhone = Utils.isBlank(this.standAloneForm1.value.emergencyContactPhone) ? "" : this.standAloneForm1.value.emergencyContactPhone;
    PreEnrollmentData.EmergencyContactRelationShip = Utils.isBlank(this.standAloneForm1.value.emergencyContactRelationShip) ? 0 : Number(this.standAloneForm1.value.emergencyContactRelationShip);
    PreEnrollmentData.MedicareNumber = this.standAloneForm1.value.mbi;
    PreEnrollmentData.IsElectronic = true;
    PreEnrollmentData.MBI = this.standAloneForm1.controls['mbi'].value
    PreEnrollmentData.MedicareEffectiveDatePartA = Utils.isBlank(this.standAloneForm1.value.medicareEffectiveDatePartA) ? null : this.standAloneForm1.value.medicareEffectiveDatePartA;
    PreEnrollmentData.MedicareEffectiveDatePartB = Utils.isBlank(this.standAloneForm1.value.medicareEffectiveDatePartB) ? null : this.standAloneForm1.value.medicareEffectiveDatePartB;
    PreEnrollmentData.IsCoverage = Utils.isBlank(this.standAloneForm1.value.isCoverage) ? false : this.standAloneForm1.value.isCoverage == "1" ? true : false;
    PreEnrollmentData.OtherCoverageName = Utils.isBlank(this.standAloneForm1.value.coverageName) ? "" : this.standAloneForm1.value.coverageName;
    PreEnrollmentData.OtherCoverageId = Utils.isBlank(this.standAloneForm1.value.coverageId) ? "" : this.standAloneForm1.value.coverageId;
    PreEnrollmentData.OtherCoverageGroup = Utils.isBlank(this.standAloneForm1.value.coverageGroup) ? "" : this.standAloneForm1.value.coverageGroup;
    PreEnrollmentData.IsMedicaid = Utils.isBlank(this.standAloneForm1.value.isMedicaid) ? false : this.standAloneForm1.value.isMedicaid == "1" ? true : false;
    PreEnrollmentData.MedicaidNumber = Utils.isBlank(this.standAloneForm1.value.medicaidnumber) ? "" : this.standAloneForm1.value.medicaidnumber;

    PreEnrollmentData.AuthorizedPersonSignature = Utils.isBlank(this.standAloneForm1.value.authorizedPersonSignature) ? "" : this.standAloneForm1.value.authorizedPersonSignature;
    PreEnrollmentData.ProposedEffectiveDate = Utils.isBlank(this.standAloneForm1.value.proposedEffectiveDate) ? null : this.standAloneForm1.value.proposedEffectiveDate;
    PreEnrollmentData.TodaysDate = Utils.isBlank(this.standAloneForm1.value.todaysDate) ? null : this.standAloneForm1.value.todaysDate;
    PreEnrollmentData.AuthorizedPersonName = Utils.isBlank(this.standAloneForm1.value.authorizedPersonName) ? "" : this.standAloneForm1.value.authorizedPersonName;
    PreEnrollmentData.AuthorizedPersonRelationshiptoEnrollee = Utils.isBlank(this.standAloneForm1.value.authorizedPersonRelationshiptoEnrollee) ? 0 : Number(this.standAloneForm1.value.authorizedPersonRelationshiptoEnrollee);
    PreEnrollmentData.AuthorizedPersonAddress = Utils.isBlank(this.standAloneForm1.value.authorizedPersonAddress) ? "" : this.standAloneForm1.value.authorizedPersonAddress;
    PreEnrollmentData.AuthorizedPersonPhoneNumber = Utils.isBlank(this.standAloneForm1.value.authorizedPersonPhoneNumber) ? "" : this.standAloneForm1.value.authorizedPersonPhoneNumber;
    PreEnrollmentData.PartDAmount = Utils.isBlank(this.standAloneForm2.value.partDAmount) ? false : this.standAloneForm2.value.partDAmount.value == "1" ? true : false;
    PreEnrollmentData.Diabetes1 = Utils.isBlank(this.standAloneForm1.value.Diabetes1) ? false : this.standAloneForm1.value.Diabetes1 == "1" ? true : false;
    PreEnrollmentData.Diabetes2 = Utils.isBlank(this.standAloneForm1.value.Diabetes2) ? false : this.standAloneForm1.value.Diabetes2 == "1" ? true : false;
    PreEnrollmentData.Cardiovascular1 = Utils.isBlank(this.standAloneForm1.value.Cardiovascular1) ? false : this.standAloneForm1.value.Cardiovascular1 == "1" ? true : false;
    PreEnrollmentData.Cardiovascular2 = Utils.isBlank(this.standAloneForm1.value.Cardiovascular2) ? false : this.standAloneForm1.value.Cardiovascular2 == "1" ? true : false;
    PreEnrollmentData.Cardiovascular3 = Utils.isBlank(this.standAloneForm1.value.Cardiovascular3) ? false : this.standAloneForm1.value.Cardiovascular3 == "1" ? true : false;
    PreEnrollmentData.Dialysis1 = Utils.isBlank(this.standAloneForm1.value.Dialysis1) ? false : this.standAloneForm1.value.Dialysis1 == "1" ? true : false;
    PreEnrollmentData.Dialysis2 = Utils.isBlank(this.standAloneForm1.value.Dialysis2) ? false : this.standAloneForm1.value.Dialysis2 == "1" ? true : false;
    PreEnrollmentData.BenefitedBy = Utils.isBlank(this.standAloneForm2.value.benefitedBy) ? "" : this.standAloneForm2.value.benefitedBy;

    PreEnrollmentData.PCPName = Utils.isBlank(this.standAloneForm1.value.PCPName) ? "" : this.standAloneForm1.value.PCPName;
    PreEnrollmentData.NepName = Utils.isBlank(this.standAloneForm1.value.NepName) ? "" : this.standAloneForm1.value.NepName;
    PreEnrollmentData.NepPhoneNumber = Utils.isBlank(this.standAloneForm1.value.NepPhoneNumber) ? "" : this.standAloneForm1.value.NepPhoneNumber;
    PreEnrollmentData.NepCity = Utils.isBlank(this.standAloneForm1.value.NepCity) ? "" : this.standAloneForm1.value.NepCity;
    PreEnrollmentData.PCPName2 = Utils.isBlank(this.standAloneForm1.value.PCPName2) ? "" : this.standAloneForm1.value.PCPName2;
    PreEnrollmentData.PCPName3 = Utils.isBlank(this.standAloneForm1.value.PCPName3) ? "" : this.standAloneForm1.value.PCPName3;
    PreEnrollmentData.City2 = Utils.isBlank(this.standAloneForm1.value.city2) ? "" : this.standAloneForm1.value.city2;
    PreEnrollmentData.City3 = Utils.isBlank(this.standAloneForm1.value.city3) ? "" : this.standAloneForm1.value.city3;
    PreEnrollmentData.Speciality2 = Utils.isBlank(this.standAloneForm1.value.speciality2) ? "" : this.standAloneForm1.value.speciality2;
    PreEnrollmentData.Speciality3 = Utils.isBlank(this.standAloneForm1.value.speciality3) ? "" : this.standAloneForm1.value.speciality3;
    PreEnrollmentData.PhoneNumber2 = Utils.isBlank(this.standAloneForm1.value.phoneNumber2) ? "" : this.standAloneForm1.value.phoneNumber2;
    PreEnrollmentData.PhoneNumber3 = Utils.isBlank(this.standAloneForm1.value.phoneNumber3) ? "" : this.standAloneForm1.value.phoneNumber3;
    PreEnrollmentData.FaxNumber2 = Utils.isBlank(this.standAloneForm1.value.faxNumber2) ? "" : this.standAloneForm1.value.faxNumber2;
    PreEnrollmentData.FaxNumber3 = Utils.isBlank(this.standAloneForm1.value.faxNumber3) ? "" : this.standAloneForm1.value.faxNumber3;
    PreEnrollmentData.City = Utils.isBlank(this.standAloneForm1.value.city) ? "" : this.standAloneForm1.value.city;
    PreEnrollmentData.Speciality = Utils.isBlank(this.standAloneForm1.value.speciality) ? "" : this.standAloneForm1.value.speciality;
    PreEnrollmentData.MedicalGroup = Utils.isBlank(this.standAloneForm1.value.medicalGroup) ? "" : this.standAloneForm1.value.medicalGroup;
    PreEnrollmentData.PhoneNumber = Utils.isBlank(this.standAloneForm1.value.phoneNumber) ? "" : this.standAloneForm1.value.phoneNumber;
    PreEnrollmentData.PCPId = Utils.isBlank(this.standAloneForm1.value.PCPId) ? 0 : this.standAloneForm1.value.PCPId;
    PreEnrollmentData.IsCurrentPatient = Utils.isBlank(this.standAloneForm1.value.PCPCurrentPatient) ? false : this.standAloneForm1.value.PCPCurrentPatient == "1" ? true : false;
    PreEnrollmentData.AccessibilityFormatLanguage = Utils.isBlank(this.standAloneForm2.value.accessibilityFormatLanguage) ? "" : this.standAloneForm2.value.accessibilityFormatLanguage;
    PreEnrollmentData.AccessibilityFormatFontSize = Utils.isBlank(this.standAloneForm2.value.accessibilityFormatFontSize) ? "" : this.standAloneForm2.value.accessibilityFormatFontSize;

    PreEnrollmentData.SEPID = Utils.isBlank(this.standAloneForm3.value.SEPID) ? 0 : Number(this.standAloneForm3.value.SEPID);
    PreEnrollmentData.SEPDate = Utils.isBlank(this.standAloneForm3.value.SEPDate) ? null : this.standAloneForm3.value.SEPDate;
    PreEnrollmentData.SalesAgentId = Utils.isBlank(this.standAloneForm3.value.salesAgentId) ? "" : this.standAloneForm3.value.salesAgentId;
    PreEnrollmentData.SalesAgentName = Utils.isBlank(this.standAloneForm3.value.salesAgentName) ? "" : this.standAloneForm3.value.salesAgentName;
    PreEnrollmentData.SalesDate = Utils.isBlank(this.standAloneForm3.value.salesDate) ? null : this.standAloneForm3.value.salesDate;
    PreEnrollmentData.SourceCode = Utils.isBlank(this.standAloneForm3.value.sourceCode) ? "" : this.standAloneForm3.value.sourceCode;
    PreEnrollmentData.Location = Utils.isBlank(this.standAloneForm3.value.location) ? "" : this.standAloneForm3.value.location;
    PreEnrollmentData.ElectionPeriod = Utils.isBlank(this.standAloneForm3.value.electionPeriod) ? "" : this.standAloneForm3.value.electionPeriod;
    PreEnrollmentData.ScopeOfSeminar = Utils.isBlank(this.standAloneForm3.value.scopeOfSeminar) ? false : this.standAloneForm3.value.scopeOfSeminar == "1" ? true : false;

    PreEnrollmentData.CreatedBy = "Anonymous";
    PreEnrollmentData.RecordStatus = RecordStatus.Active;
    PreEnrollmentData.RecordStatusChangeComment = 'Active';


    return PreEnrollmentData;
  }

}
