import { AppConstant } from '../common/app-constants';
import { Utils } from '../common/app-functions';
import { environment } from "../../environments/environment";

export class CoreComponentModel {
    constructor() { }

    get enviourment(): any {
        return environment;
    }

    get utils(): any {
        return Utils;
    }

    get appConstant(): any{
        return AppConstant;
    }
}