export class AppConstant {

    static textYesConfirm = 'Yes';
    static textNoConfirm = 'No';
    static textOkConfirm = 'Ok';

    static readonly mbiValidationMessage = "MBI is not in valid format, Do you want to modify?";

    static readonly mbiMedicaidErrorMessage = "MBI and Medicaid can not be same, You need to modify it?";

    static readonly agentIfInvaildMessage = "Broker Id does not exist, You want to modify it?";

}