export enum CodeType {
    Gender = 100,
    MemberRelationship = 51,
    Prefix = 52,
    HIPAACommunication = 59,
    CMSContractCode = 515,
    CMSPBPCode = 516,
    Race = 56,
    Ethnicity = 57
}

export enum HealthPlan {
    AaneelCare = "AaneelCare",
    HPS = "Gold Kidney"
}

export enum Page {
    MEMBER_ADD_EDIT = <any>"1B009555-7057-4189-AC3F-891065C85006",
    ENROLLMENT_PAGE = <any>"992030E6-4959-4DC4-97CB-F413CB99756F"
}

export enum accessibilityFormatLanguage {
    Default = 'English',
    Second = 'Spanish',
    Third = 'Chinese',
}

export enum accessibilityFormatFontSize {
    Default = 'Regular',
    Second = 'Large',
}

export enum RecordStatus {
    Active = 0,
    Termed = 1,
    InActive = 2,
    Deleted = 3,
    VoidOrInvalid = 4,
    Pend = 5,
    Cancel = 6,
}




