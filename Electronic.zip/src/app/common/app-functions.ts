import * as moment from 'moment';
import { HttpResponse } from '@angular/common/http';

export class Utils {

    static isMbiNumberValid(mbiNumber: string): boolean {
        let isMbiValid: boolean = false;
        if (!Utils.isBlank(mbiNumber)) {
            let MBI_REGEXP: RegExp = /\b[1-9][AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y]{2}\d{2}\b/gm
            if (MBI_REGEXP.test(mbiNumber)) {
                isMbiValid = true;
            }
        }
        return isMbiValid;
    }

    static isBlank(val: any): boolean {
        return val == undefined || val == null || val == '' || val == "" || val == " ";
    }

    static isValidString(value: string): boolean {
        let isMbiValid: boolean = false;
        if (!Utils.isBlank(value)) {
            let MBI_REGEXP: RegExp = /^[A-Za-z]+$/gm
            if (MBI_REGEXP.test(value)) {
                isMbiValid = true;
            }
        }
        return isMbiValid;
    }

    public static JSonTryParse(value: any) {
        try {
            return JSON.parse(value);
        }
        catch (e) {
            if (value === "undefined")
                return void 0;

            return value;
        }
    }

    private static b64DecodeUnicode(str: any) {
        return decodeURIComponent(Array.prototype.map.call(atob(str), (c: any) => {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    }

    public static urlBase64Decode(str: string): string {
        let output = str.replace(/-/g, '+').replace(/_/g, '/');
        switch (output.length % 4) {
            case 0: { break; }
            case 2: { output += '=='; break; }
            case 3: { output += '='; break; }
            default: {
                throw 'Illegal base64url string!';
            }
        }
        return this.b64DecodeUnicode(output);
    }

    public static decodeToken(token: string): any {
        let parts = token.split('.');

        if (parts.length !== 3) {
            throw new Error('JWT must have 3 parts');
        }

        let decoded = this.urlBase64Decode(parts[1]);
        if (!decoded) {
            throw new Error('Cannot decode the token');
        }

        return JSON.parse(decoded);
    }

    public static setAccessTokenValues(token: any) {
        localStorage.setItem('preEnrollmentAccessToken', token);
        let decodedIdToken = this.decodeToken(JSON.stringify(token));
        let fullExpiryTime = decodedIdToken.exp;
        localStorage.setItem('preEnrollmentTokenGeneratedAt', fullExpiryTime);
    }

    public static removeAccessTokenValues() {
        localStorage.removeItem('preEnrollmentAccessToken');
        localStorage.removeItem('preEnrollmentTokenGeneratedAt');
    }
}