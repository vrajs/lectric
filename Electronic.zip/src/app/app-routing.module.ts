import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PreEnrollmentFormComponent } from './PreEnrollmentForm/PreEnrollmentForm.component';
import { Page2Component } from './page2/page2.component';
import { Page3Component } from './page3/page3.component';

 export const routes: Routes = [
  { path : '', component: PreEnrollmentFormComponent, pathMatch: 'full' },
  { path :'section1', component :PreEnrollmentFormComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
