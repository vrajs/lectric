import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CustomConfimDialogModel } from '../../common/custome-confirm-dialog.model'
import { CoreComponentModel } from '../../common/core-component.model'


@Component({
  selector: 'app-custom-confirm-dialog',
  templateUrl: './custom-confirm-dialog.component.html',
  styleUrls: ['./custom-confirm-dialog.component.css']
})
export class CustomConfirmDialogComponent extends CoreComponentModel implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<CustomConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CustomConfimDialogModel) {
      super();
      dialogRef.disableClose = true;
     }

  ngOnInit(): void {
  }
  
  onCancel(): void {
    this.dialogRef.close();
  }

  onOk(): void {
    this.dialogRef.close({ data: this.data.item });
  }

}
