import { HttpBackend, HttpClient, HttpParams, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { switchMap, tap } from "rxjs/operators";
import { Utils } from "src/app/common/app-functions";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  constructor(private http: HttpClient
    , private httpBackend: HttpBackend) {
    this.http = new HttpClient(httpBackend);
  }

  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>("");

  getToken() {
    return localStorage.getItem("preEnrollmentAccessToken")
  }

  get accessTokenExpiryFullTime() {
    if (!Utils.isBlank(localStorage.getItem("preEnrollmentTokenGeneratedAt"))) {
      return JSON.parse(JSON.stringify(localStorage.getItem("preEnrollmentTokenGeneratedAt")));
    } else {
      return "";
    }
  }

  get isSessionExpired(): boolean {
    if (!Utils.isBlank(this.accessTokenExpiryFullTime)) {     
      return !(this.accessTokenExpiryFullTime.valueOf() >
        Math.floor(new Date().getTime() / 1000));      
    } else {
      return false;
    }
  }

  refreshTokenAPIcall() {
    return this.http.get<any>(`${environment.serviceApiUrl}/api/PreEnrollment/GetToken`);
  }
}
