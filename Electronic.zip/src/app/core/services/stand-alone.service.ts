import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { map, Observable, Subject } from 'rxjs';
import { CommonCodeModel } from '../models/common/common-code.model';
import { ZipCodeModel } from '../models/common/zip-code.model';
import { CommonCodeConfigurationModel } from '../models/common/common-code-configuration.model';
import { SEPReasonCodeTypeModel } from '../models/common/sepReasonCodeType.model';
import { ProviderCodeModel } from '../models/common/provider-code.model';
import { PreEnrollmentModel } from '../models/common/PreEnrollment.model';

@Injectable({
  providedIn: 'root'
})
export class StandAloneService {
  public commonCodeModelData!: Observable<CommonCodeModel[]>;

  constructor(private httpClient: HttpClient) {
  }

  getAccessToken(): Observable<any> {
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/PreEnrollment/GetToken`);
  }

  getCommonCodeByCodeTypeId(codeTypeId: number): Observable<CommonCodeModel[]> {
    return this.httpClient.get<CommonCodeModel[]>(`${environment.serviceApiUrl}/api/PreEnrollment/GetCommonCodeByCodeTypeId/${codeTypeId}`).pipe(
      map(res => {
        return res as CommonCodeModel[];
      })
    );
  }
  getPBPByCodeTypeId(codeTypeId: number): Observable<CommonCodeModel[]> {
    return this.httpClient.get<CommonCodeModel[]>(`${environment.serviceApiUrl}/api/PreEnrollment/GetPBPByCodeTypeId/${codeTypeId}`).pipe(
      map(res => {
        return res as CommonCodeModel[];
      })
    );
  }

  getZipCodesDetails(searchValue: string): Observable<ZipCodeModel> {
    let recParams = new HttpParams();
    recParams = recParams.append('searchValue', searchValue.toString());
    return this.httpClient.get<ZipCodeModel>(`${environment.serviceApiUrl}/api/PreEnrollment/GetZipCodeBySearchValue/${searchValue}`, { params: recParams }).pipe(
      map(res => {
        return res as ZipCodeModel;
      })
    );
  }

  getCommonCodeConfigurationByCodeTypeId(PageId: string, CodeTypeId: number): Observable<CommonCodeConfigurationModel[]> {
    return this.httpClient.get<CommonCodeConfigurationModel[]>(`${environment.serviceApiUrl}/api/PreEnrollment/GetCommonCodeConfigurationByCodeTypeId/${PageId}/${CodeTypeId}`).pipe(
      map(res => {
        return res as CommonCodeConfigurationModel[];
      })
    );
  }

  getSepReason(): Observable<SEPReasonCodeTypeModel[]> {
    return this.httpClient.get<SEPReasonCodeTypeModel[]>(`${environment.serviceApiUrl}/api/PreEnrollment/GetSepReason`).pipe(
      map(res => {
        return res as SEPReasonCodeTypeModel[];
      })
    );
  }
  getApplicationStatusId(selectedMemberEnrollmentHeaderId: number): Observable<number> {
    return this.httpClient.get<number>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetApplicationStatusId?MemberEnrollmentHeaderID=${selectedMemberEnrollmentHeaderId}`,).pipe(
      map(res => {
       
        return res as number;
      })
    );
  }
  GetProviderNameByProCode(proCode: string): Observable<ProviderCodeModel> {
    return this.httpClient.get<ProviderCodeModel>(`${environment.serviceApiUrl}/api/PreEnrollment/GetProviderNameByProCode/${proCode}`);
  }

  InsertPreEnrollmentMember(model: PreEnrollmentModel): Observable<PreEnrollmentModel> {
    return this.httpClient.post<PreEnrollmentModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/`, model);
  }
}
