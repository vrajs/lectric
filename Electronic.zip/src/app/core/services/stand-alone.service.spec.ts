import { TestBed } from '@angular/core/testing';

import { StandAloneService } from './stand-alone.service';

describe('StandAloneService', () => {
  let service: StandAloneService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StandAloneService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
