import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from "@angular/common/http";
import { Injectable, Injector } from "@angular/core";
import { catchError, filter, take, tap } from "rxjs/operators";
import { switchMap, finalize } from "rxjs/operators";
import { Router } from "@angular/router";
import { BehaviorSubject, Observable, throwError } from "rxjs";
import { AuthService } from "../../core/services/auth.service";
import { Utils } from "src/app/common/app-functions";
import { StandAloneService } from "../services/stand-alone.service";

@Injectable()
export class BasicAuthInterceptor implements HttpInterceptor {

  isRefreshingToken = false;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>("");
  token: string = '';
  constructor(private inject: Injector, private authService: AuthService) { }
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    let isSessionExpired = this.authService.isSessionExpired;
    
    if (!Utils.isBlank(isSessionExpired) && isSessionExpired) {      
      return this.authService.refreshTokenAPIcall().pipe(
        tap(token => {
          if(!Utils.isBlank(token)){
            Utils.removeAccessTokenValues();
            Utils.setAccessTokenValues(token);
          }        
        }),take(1),
        switchMap(token => {
          const newRequest = this.cloneToken(request);
          return next.handle(newRequest);
        })
      );
    } else {
      const newRequest = this.cloneToken(request);
      return next.handle(newRequest);
    }
  }

  cloneToken(request: HttpRequest<unknown>): HttpRequest<unknown> {
    var validateToken = this.authService.getToken();
    validateToken = JSON.parse(JSON.stringify(validateToken));
    const cloned = request.clone({
      setHeaders: {
        Authorization: `Bearer ${validateToken}`
      }
    });

    return cloned;
  }

}
