
export class ProviderCodeModel {
    public providerCodeId: number;
    public providerId: number;
    public controlTypeId: number;
    public codeTypeId: number;
    public codeValue: string;
    public lastName: string;
    public firstName: string;
    public middleName: string;
    public fullName: string;
    public codeName: string;
    public effectiveDate: Date| null ;
    public termDate?: Date | null ;

    constructor() {
        this.providerCodeId = 0;
        this.providerId = 0;
        this.controlTypeId = 0;
        this.codeTypeId = 0;
        this.codeValue = "";
        this.lastName = "";
        this.firstName = "";
        this.middleName = "";
        this.fullName = "";
        this.codeName = "";
        this.effectiveDate = null;
        this.termDate = null;
    }
}
