export class SEPReasonCodeTypeModel {
    'sepReasonCodeID': number;
    'question': string;
    'electionTypeCodeId': number;
    'electionTypeCode': string;
    'reasonCode': string;
    'dateToBeEntered': number;
    'oecSepReasonCodeMapping': string;
    'checked':boolean;
}