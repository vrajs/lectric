export class CommonCodeModel {
    public commonCodeID: number;
    public addedSource: string;
    public charValue: string;
    public code: string;
    public codeTypeId: number;
    public codeType: string;
    public displayOrder: number;
    public effectiveDate: Date | null | undefined;
    public loadComment: string;
    public longDescription: string;
    public numericValue: number;
    public otherValue: string;
    public shortName: string;
    public termDate: Date | null | undefined;
    public controlTypeId: number;
    public isDisable: boolean;
    public defaultValue: number | string;
    public checked:boolean | false | undefined;

    constructor() {
        this.commonCodeID = 0;
        this.charValue = "";
        this.longDescription = "";
        this.addedSource = "";
        this.charValue = "";
        this.code = "";
        this.codeTypeId = 0;
        this.codeType = "";
        this.displayOrder = 0;
        this.loadComment = "";
        this.longDescription = "";
        this.numericValue = 0;
        this.otherValue = "";
        this.shortName = "";
        this.controlTypeId = 0;
        this.isDisable = false;
        this.defaultValue = "";
    }
}
